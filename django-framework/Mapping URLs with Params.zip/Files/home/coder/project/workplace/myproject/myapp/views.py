from django.shortcuts import render
from django.http import HttpResponse
from http.client import HTTPResponse

# Create your views here.
def drinks(request, drink_name):

    # create a dict inside drinks 
    drink = {
        'mocha' : 'type of coffee',
        'tea' : 'type of hot beverage',
        'lemonade': 'type of refreshment'
    }

    # Create a variable called choice_of_drink and assign it the value of the drink_name by passing it inside the drink dictionary.
    choice_of_drink = drink[drink_name]
    return HttpResponse(f"<h2>{drink_name}</h2> " + choice_of_drink)
